// Dedicated Playgama shell; all platform APIs are used only after initialize().
(() => {
  const STORAGE_KEY = 'chain_reaction_settings_v2';
  const callbacks = new Set();
  let initialized = false, loaded = false, saved = '', status = 'idle';
  let pending = null, saving = null, paused = false, audio = true;
  let adBusy = false, adOpened = false, adDone = null, adTimer = null;
  let readySent = false, playing = false, startedAt = 0, lastAdAt = -Infinity;
  let initializePromise = null;
  function bounded(promise, milliseconds) {
    let timer;
    const deadline = new Promise((_, reject) => {
      timer = setTimeout(() => reject(new Error('Platform storage response timed out.')), milliseconds);
    });
    return Promise.race([promise, deadline]).finally(() => clearTimeout(timer));
  }
  function notify() {
    for (const cb of callbacks) cb(paused || adBusy, audio && !adBusy);
  }
  async function flush() {
    if (saving) return saving;
    saving = (async () => {
      // A microtask coalesces rapid changes; writes never race or finish out of order.
      await Promise.resolve();
      while (pending !== null) {
        const value = pending;
        pending = null;
        try {
          await window.bridge.storage.set([STORAGE_KEY], [value]);
          status = 'saved';
        } catch (error) {
          status = 'failed';
          console.warn('Playgama progress save failed.', error);
        }
      }
    })();
    try { await saving; } finally { saving = null; }
  }
  function finishAd() {
    if (!adBusy) return;
    clearTimeout(adTimer);
    adTimer = null;
    adBusy = false;
    if (adOpened) lastAdAt = Date.now();
    const callback = adDone;
    adDone = null;
    notify();
    // Never invoke a Godot callback before its await has been installed.
    queueMicrotask(() => callback?.());
  }
  window.ChainReactionPlaygama = {
    initialize() {
      if (initializePromise) return initializePromise;
      initializePromise = (async () => {
        if (!window.bridge) throw new Error('Could not connect to Playgama. Please reload.');
        await window.bridge.initialize();
        initialized = true;
        startedAt = Date.now();
        const platform = window.bridge.platform;
        paused = platform.isPaused;
        audio = platform.isAudioEnabled;
        platform.on(window.bridge.EVENT_NAME.PAUSE_STATE_CHANGED, value => { paused = value; notify(); });
        platform.on(window.bridge.EVENT_NAME.AUDIO_STATE_CHANGED, value => { audio = value; notify(); });
        window.bridge.advertisement.on(window.bridge.EVENT_NAME.INTERSTITIAL_STATE_CHANGED, state => {
          if (state === 'opened') adOpened = true;
          if (state === 'closed' || state === 'failed') finishAd();
        });
        try {
          const values = await bounded(window.bridge.storage.get([STORAGE_KEY]), 5000);
          if (values[0] !== null && values[0] !== undefined && typeof values[0] !== 'string') throw new Error('Invalid progress format');
          saved = values[0] || '';
          loaded = true;
        } catch (error) {
          // Unknown remote progress must never be overwritten with a fresh save.
          status = 'failed';
          console.warn('Playgama progress load failed; session-only progress.', error);
        }
        notify();
      })();
      return initializePromise;
    },
    language() { return initialized ? window.bridge.platform.language : 'en'; },
    storageLoaded() { return loaded; },
    savedConfig() { return saved; },
    saveStatus() { return status; },
    queueSave(value) {
      if (!loaded || typeof value !== 'string') return false;
      saved = value;
      pending = value;
      status = 'pending';
      void flush();
      return true;
    },
    flush,
    attach(cb) { callbacks.add(cb); cb(paused || adBusy, audio && !adBusy); },
    detach(cb) { callbacks.delete(cb); },
    gameReady() {
      if (!initialized || readySent) return;
      readySent = true;
      requestAnimationFrame(() => requestAnimationFrame(() => window.bridge.platform.sendMessage('game_ready')));
    },
    setPlaying(value) {
      if (!initialized || playing === value) return;
      playing = value;
      window.bridge.platform.sendMessage(value ? 'gameplay_started' : 'gameplay_stopped');
    },
    requestBreak(cb) {
      if (!initialized || adBusy || !window.bridge.advertisement.isInterstitialSupported || Date.now() - startedAt < 120000 || Date.now() - lastAdAt < 90000) return false;
      adBusy = true;
      adOpened = false;
      adDone = cb;
      notify();
      // Save before an ad; hold the next round until close/failure, not its request.
      void (async () => {
        // Keep writes serialized even if one is stalled. Only this wait expires;
        // do not launch a second write that could race a late first completion.
        try { await bounded(flush(), 1500); }
        catch (error) { status = 'failed'; console.warn('Continuing while progress save is pending.', error); }
        adTimer = setTimeout(() => { if (!adOpened) finishAd(); }, 20000);
        try { window.bridge.advertisement.showInterstitial('round_complete'); }
        catch (_) { finishAd(); }
      })();
      return true;
    }
  };
})();
